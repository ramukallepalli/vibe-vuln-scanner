/**
 * Background service worker for the extension
 */

// CISA KEV catalog URL
const CISA_KEV_URL = 'https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json';

// Store scan results and KEV data
let scanResults = new Map();
let kevCatalog = null;
let kevLastUpdated = null;

// Fetch CISA KEV catalog
async function fetchKEVCatalog() {
  try {
    console.log('Fetching CISA KEV catalog...');
    const response = await fetch(CISA_KEV_URL);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    kevCatalog = data.vulnerabilities || [];
    kevLastUpdated = Date.now();

    // Store in chrome.storage for persistence
    await chrome.storage.local.set({
      kevCatalog: kevCatalog,
      kevLastUpdated: kevLastUpdated
    });

    console.log(`CISA KEV catalog loaded: ${kevCatalog.length} vulnerabilities`);
    return kevCatalog;
  } catch (error) {
    console.error('Failed to fetch CISA KEV catalog:', error);

    // Try to load from storage as fallback
    const stored = await chrome.storage.local.get(['kevCatalog', 'kevLastUpdated']);
    if (stored.kevCatalog) {
      kevCatalog = stored.kevCatalog;
      kevLastUpdated = stored.kevLastUpdated;
      console.log('Using cached KEV catalog');
      return kevCatalog;
    }

    return [];
  }
}

// Get KEV catalog (fetch if needed)
async function getKEVCatalog() {
  // Refresh if older than 24 hours or not loaded
  const ONE_DAY = 24 * 60 * 60 * 1000;
  const needsRefresh = !kevCatalog || !kevLastUpdated || (Date.now() - kevLastUpdated > ONE_DAY);

  if (needsRefresh) {
    return await fetchKEVCatalog();
  }

  return kevCatalog;
}

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'scanComplete') {
    const tabId = sender.tab?.id;

    if (tabId) {
      scanResults.set(tabId, {
        url: message.url,
        isVibeApp: message.isVibeApp,
        vulnerabilities: message.vulnerabilities,
        timestamp: Date.now()
      });

      // Update badge with vulnerability count
      updateBadge(tabId, message.vulnerabilities.length);
    }
  }

  if (message.action === 'getKEVCatalog') {
    getKEVCatalog().then(catalog => {
      sendResponse({ catalog });
    });
    return true; // Will respond asynchronously
  }
});

// Update extension badge
function updateBadge(tabId, count) {
  if (count === 0) {
    chrome.action.setBadgeText({ tabId, text: '' });
    chrome.action.setBadgeBackgroundColor({ tabId, color: '#4CAF50' });
  } else if (count < 5) {
    chrome.action.setBadgeText({ tabId, text: String(count) });
    chrome.action.setBadgeBackgroundColor({ tabId, color: '#FF9800' });
  } else {
    chrome.action.setBadgeText({ tabId, text: String(count) });
    chrome.action.setBadgeBackgroundColor({ tabId, color: '#F44336' });
  }
}

// Handle extension installation
chrome.runtime.onInstalled.addListener(() => {
  console.log('Vibe Vulnerability Scanner installed');
  // Fetch KEV catalog on install
  fetchKEVCatalog();
});

// Fetch KEV catalog on startup
fetchKEVCatalog();

// Refresh KEV catalog periodically (every 6 hours)
setInterval(() => {
  fetchKEVCatalog();
}, 6 * 60 * 60 * 1000);

// Export scan results getter
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'getResults') {
    const results = scanResults.get(message.tabId);
    sendResponse(results || null);
  }
});
