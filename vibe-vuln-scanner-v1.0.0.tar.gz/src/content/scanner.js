/**
 * Content script that runs on web pages to detect vulnerabilities
 */

class VulnerabilityScanner {
  constructor() {
    this.vulnerabilities = [];
    this.isVibeCodedApp = false;
  }

  /**
   * Detect if the current page is a vibe-coded application
   */
  detectVibeApp() {
    // Check for common vibe framework signatures
    const indicators = [
      // Check for vibe-specific attributes or classes
      document.querySelector('[data-vibe]'),
      document.querySelector('.vibe-app'),
      // Check for vibe in meta tags
      document.querySelector('meta[name="generator"][content*="vibe"]'),
      // Check for vibe in script sources
      Array.from(document.scripts).some(script =>
        script.src.includes('vibe') || script.textContent.includes('vibe')
      )
    ];

    this.isVibeCodedApp = indicators.some(indicator => indicator);
    return this.isVibeCodedApp;
  }

  /**
   * Scan for XSS vulnerabilities
   */
  scanXSS() {
    const findings = [];

    // Check for inline event handlers
    const elementsWithEvents = document.querySelectorAll(
      '[onclick], [onerror], [onload], [onmouseover]'
    );

    if (elementsWithEvents.length > 0) {
      findings.push({
        type: 'XSS',
        severity: 'HIGH',
        description: `Found ${elementsWithEvents.length} elements with inline event handlers`,
        elements: Array.from(elementsWithEvents).slice(0, 5).map(el => el.outerHTML.substring(0, 100))
      });
    }

    // Check for dangerous innerHTML usage in scripts
    const scripts = Array.from(document.scripts);
    scripts.forEach((script, idx) => {
      if (script.textContent.includes('.innerHTML')) {
        findings.push({
          type: 'XSS',
          severity: 'MEDIUM',
          description: `Script ${idx} uses innerHTML which may be vulnerable to XSS`,
          location: script.src || 'inline script'
        });
      }
    });

    return findings;
  }

  /**
   * Extract library information from script sources
   */
  extractLibraryInfo(src) {
    if (!src) return null;

    // Common patterns for detecting libraries and versions
    const patterns = [
      // jQuery: jquery-3.6.0.min.js or jquery@3.6.0
      { regex: /jquery[-@]?(\d+\.\d+\.\d+)/i, name: 'jQuery' },
      // React: react@17.0.2 or react.17.0.2.js
      { regex: /react[-@.](\d+\.\d+\.\d+)/i, name: 'React' },
      // Vue: vue@3.2.0 or vue.3.2.0.js
      { regex: /vue[-@.](\d+\.\d+\.\d+)/i, name: 'Vue.js' },
      // Angular: angular@12.0.0
      { regex: /angular[-@.](\d+\.\d+\.\d+)/i, name: 'Angular' },
      // Bootstrap: bootstrap@5.1.3
      { regex: /bootstrap[-@.](\d+\.\d+\.\d+)/i, name: 'Bootstrap' },
      // Lodash: lodash@4.17.21
      { regex: /lodash[-@.](\d+\.\d+\.\d+)/i, name: 'Lodash' },
      // Moment.js: moment@2.29.1
      { regex: /moment[-@.](\d+\.\d+\.\d+)/i, name: 'Moment.js' },
      // Chart.js: chart.js@3.7.0
      { regex: /chart\.?js[-@.](\d+\.\d+\.\d+)/i, name: 'Chart.js' },
      // D3: d3@7.0.0
      { regex: /d3[-@.](\d+\.\d+\.\d+)/i, name: 'D3.js' },
      // Axios: axios@0.21.1
      { regex: /axios[-@.](\d+\.\d+\.\d+)/i, name: 'Axios' }
    ];

    for (const pattern of patterns) {
      const match = src.match(pattern.regex);
      if (match) {
        return {
          name: pattern.name,
          version: match[1]
        };
      }
    }

    return null;
  }

  /**
   * Scan for insecure dependencies
   */
  scanDependencies() {
    const findings = [];
    const scripts = Array.from(document.scripts);

    scripts.forEach(script => {
      const src = script.src;

      // Check for HTTP (non-HTTPS) script sources
      if (src && src.startsWith('http://')) {
        findings.push({
          type: 'INSECURE_DEPENDENCY',
          severity: 'HIGH',
          description: 'Loading script over insecure HTTP connection',
          url: src
        });
      }

      // Check for CDN without SRI
      if (src && src.includes('cdn') && !script.integrity) {
        findings.push({
          type: 'MISSING_SRI',
          severity: 'MEDIUM',
          description: 'CDN script loaded without Subresource Integrity (SRI)',
          url: src
        });
      }
    });

    return findings;
  }

  /**
   * Scan for known exploited vulnerabilities using CISA KEV catalog
   */
  async scanKnownVulnerabilities() {
    const findings = [];

    try {
      // Get KEV catalog from background script
      const response = await chrome.runtime.sendMessage({ action: 'getKEVCatalog' });

      if (!response || !response.catalog) {
        console.log('KEV catalog not available');
        return findings;
      }

      const kevCatalog = response.catalog;
      const scripts = Array.from(document.scripts);
      const detectedLibraries = new Map();

      // Extract library information from all scripts
      scripts.forEach(script => {
        const libInfo = this.extractLibraryInfo(script.src);
        if (libInfo) {
          // Store the library, keeping the lowest version found
          const existing = detectedLibraries.get(libInfo.name);
          if (!existing || this.compareVersions(libInfo.version, existing.version) < 0) {
            detectedLibraries.set(libInfo.name, {
              version: libInfo.version,
              url: script.src
            });
          }
        }
      });

      // Check meta tags for framework versions
      const metaGenerator = document.querySelector('meta[name="generator"]');
      if (metaGenerator) {
        const content = metaGenerator.getAttribute('content');
        const libInfo = this.extractLibraryInfo(content);
        if (libInfo && !detectedLibraries.has(libInfo.name)) {
          detectedLibraries.set(libInfo.name, {
            version: libInfo.version,
            source: 'meta tag'
          });
        }
      }

      // Cross-reference detected libraries with KEV catalog
      for (const [libName, libData] of detectedLibraries.entries()) {
        // Search KEV catalog for vulnerabilities matching this library
        const matchingVulns = kevCatalog.filter(vuln => {
          const vulnProduct = vuln.product?.toLowerCase() || '';
          const searchName = libName.toLowerCase().replace(/\.js$/, '');

          return vulnProduct.includes(searchName) || searchName.includes(vulnProduct);
        });

        if (matchingVulns.length > 0) {
          matchingVulns.forEach(vuln => {
            findings.push({
              type: 'KNOWN_EXPLOITED_VULNERABILITY',
              severity: 'CRITICAL',
              description: `${libName} ${libData.version} - ${vuln.vulnerabilityName}`,
              cveId: vuln.cveID,
              dateAdded: vuln.dateAdded,
              dueDate: vuln.dueDate,
              product: vuln.product,
              vendor: vuln.vendorProject,
              detectedVersion: libData.version,
              url: libData.url || libData.source,
              cisaDescription: vuln.shortDescription,
              requiredAction: vuln.requiredAction
            });
          });
        }
      }

      // Also scan page content for CVE mentions (might indicate vulnerable components)
      const pageText = document.body.innerText;
      const cvePattern = /CVE-\d{4}-\d{4,7}/gi;
      const cveMentions = pageText.match(cvePattern);

      if (cveMentions) {
        const uniqueCVEs = [...new Set(cveMentions)];
        uniqueCVEs.forEach(cve => {
          const kevEntry = kevCatalog.find(vuln => vuln.cveID === cve);
          if (kevEntry) {
            findings.push({
              type: 'CVE_MENTIONED',
              severity: 'HIGH',
              description: `Known exploited CVE mentioned in page: ${cve}`,
              cveId: kevEntry.cveID,
              cisaDescription: kevEntry.shortDescription,
              product: kevEntry.product,
              vendor: kevEntry.vendorProject
            });
          }
        });
      }

    } catch (error) {
      console.error('Error scanning for known vulnerabilities:', error);
    }

    return findings;
  }

  /**
   * Compare version strings (simple semver comparison)
   */
  compareVersions(v1, v2) {
    const parts1 = v1.split('.').map(Number);
    const parts2 = v2.split('.').map(Number);

    for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
      const p1 = parts1[i] || 0;
      const p2 = parts2[i] || 0;

      if (p1 > p2) return 1;
      if (p1 < p2) return -1;
    }

    return 0;
  }

  /**
   * Scan for sensitive data exposure
   */
  scanDataExposure() {
    const findings = [];
    const pageText = document.body.innerText;

    // Check for exposed API keys or tokens
    const patterns = [
      { regex: /(?:api[_-]?key|apikey)[\s:=]["']?([a-zA-Z0-9_\-]{20,})/gi, name: 'API Key' },
      { regex: /(?:secret|token)[\s:=]["']?([a-zA-Z0-9_\-]{20,})/gi, name: 'Secret/Token' },
      { regex: /sk-[a-zA-Z0-9]{32,}/g, name: 'OpenAI API Key' }
    ];

    patterns.forEach(pattern => {
      const matches = pageText.match(pattern.regex);
      if (matches && matches.length > 0) {
        findings.push({
          type: 'DATA_EXPOSURE',
          severity: 'CRITICAL',
          description: `Possible ${pattern.name} exposed in page content`,
          count: matches.length
        });
      }
    });

    return findings;
  }

  /**
   * Scan for CSP issues
   */
  scanCSP() {
    const findings = [];
    const cspMeta = document.querySelector('meta[http-equiv="Content-Security-Policy"]');

    if (!cspMeta) {
      findings.push({
        type: 'MISSING_CSP',
        severity: 'MEDIUM',
        description: 'No Content Security Policy meta tag found'
      });
    } else {
      const csp = cspMeta.getAttribute('content');

      // Check for unsafe-inline
      if (csp.includes('unsafe-inline')) {
        findings.push({
          type: 'WEAK_CSP',
          severity: 'MEDIUM',
          description: 'CSP allows unsafe-inline which may enable XSS attacks'
        });
      }

      // Check for unsafe-eval
      if (csp.includes('unsafe-eval')) {
        findings.push({
          type: 'WEAK_CSP',
          severity: 'HIGH',
          description: 'CSP allows unsafe-eval which may enable code injection'
        });
      }
    }

    return findings;
  }

  /**
   * Run all scans
   */
  async runScans() {
    this.detectVibeApp();

    // Run synchronous scans
    const syncFindings = [
      ...this.scanXSS(),
      ...this.scanDependencies(),
      ...this.scanDataExposure(),
      ...this.scanCSP()
    ];

    // Run async KEV scan
    const kevFindings = await this.scanKnownVulnerabilities();

    this.vulnerabilities = [
      ...syncFindings,
      ...kevFindings
    ];

    // Send results to popup
    chrome.runtime.sendMessage({
      action: 'scanComplete',
      isVibeApp: this.isVibeCodedApp,
      vulnerabilities: this.vulnerabilities,
      url: window.location.href
    });

    return this.vulnerabilities;
  }
}

// Auto-run scanner when page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    const scanner = new VulnerabilityScanner();
    scanner.runScans();
  });
} else {
  const scanner = new VulnerabilityScanner();
  scanner.runScans();
}

// Listen for manual scan requests
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'startScan') {
    const scanner = new VulnerabilityScanner();
    scanner.runScans().then(results => {
      sendResponse({ success: true, vulnerabilities: results });
    });
    return true; // Will respond asynchronously
  }
});
