/**
 * Popup UI logic
 */

document.addEventListener('DOMContentLoaded', async () => {
  const loadingEl = document.getElementById('loading');
  const resultsEl = document.getElementById('results');
  const errorEl = document.getElementById('error');
  const rescanBtn = document.getElementById('rescan-btn');

  try {
    // Get current tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab) {
      throw new Error('No active tab found');
    }

    // Request scan results
    chrome.runtime.sendMessage(
      { action: 'getResults', tabId: tab.id },
      (response) => {
        loadingEl.style.display = 'none';

        if (response && response.vulnerabilities) {
          displayResults(response);
          resultsEl.style.display = 'block';
        } else {
          // No results yet, trigger a scan
          triggerScan(tab.id);
        }
      }
    );

    // Rescan button handler
    rescanBtn.addEventListener('click', () => {
      resultsEl.style.display = 'none';
      loadingEl.style.display = 'block';
      triggerScan(tab.id);
    });

  } catch (error) {
    console.error('Error:', error);
    loadingEl.style.display = 'none';
    errorEl.style.display = 'block';
  }
});

function triggerScan(tabId) {
  chrome.tabs.sendMessage(tabId, { action: 'startScan' }, (response) => {
    if (chrome.runtime.lastError) {
      console.error('Scan error:', chrome.runtime.lastError);
      document.getElementById('loading').style.display = 'none';
      document.getElementById('error').style.display = 'block';
      return;
    }

    // Wait a moment for results to be stored
    setTimeout(() => {
      chrome.runtime.sendMessage(
        { action: 'getResults', tabId },
        (results) => {
          document.getElementById('loading').style.display = 'none';
          if (results) {
            displayResults(results);
            document.getElementById('results').style.display = 'block';
          }
        }
      );
    }, 500);
  });
}

function displayResults(data) {
  const { isVibeApp, vulnerabilities } = data;

  // Update vibe app indicator
  const vibeIndicator = document.getElementById('vibe-indicator');
  vibeIndicator.textContent = isVibeApp
    ? '✅ Vibe-coded app detected'
    : 'ℹ️ Not detected as a vibe app';

  // Count vulnerabilities by severity
  const counts = {
    total: vulnerabilities.length,
    critical: vulnerabilities.filter(v => v.severity === 'CRITICAL').length,
    high: vulnerabilities.filter(v => v.severity === 'HIGH').length,
    medium: vulnerabilities.filter(v => v.severity === 'MEDIUM').length
  };

  // Update summary
  document.getElementById('total-vulns').textContent = counts.total;
  document.getElementById('critical-count').textContent = counts.critical;
  document.getElementById('high-count').textContent = counts.high;
  document.getElementById('medium-count').textContent = counts.medium;

  // Display vulnerability list
  const listEl = document.getElementById('vulnerabilities-list');

  if (vulnerabilities.length === 0) {
    listEl.innerHTML = '<div class="no-vulns">✓ No vulnerabilities detected!</div>';
  } else {
    listEl.innerHTML = vulnerabilities.map(vuln => {
      // Build vulnerability details HTML
      let detailsHtml = '';

      // Add KEV-specific details
      if (vuln.type === 'KNOWN_EXPLOITED_VULNERABILITY') {
        detailsHtml = `
          <div class="vuln-details">
            <div class="vuln-detail-item"><strong>CVE:</strong> ${vuln.cveId}</div>
            <div class="vuln-detail-item"><strong>Product:</strong> ${vuln.product || 'N/A'}</div>
            <div class="vuln-detail-item"><strong>Vendor:</strong> ${vuln.vendor || 'N/A'}</div>
            <div class="vuln-detail-item"><strong>Detected Version:</strong> ${vuln.detectedVersion || 'Unknown'}</div>
            <div class="vuln-detail-item"><strong>Date Added to KEV:</strong> ${vuln.dateAdded || 'N/A'}</div>
            ${vuln.dueDate ? `<div class="vuln-detail-item"><strong>CISA Due Date:</strong> ${vuln.dueDate}</div>` : ''}
            ${vuln.requiredAction ? `<div class="vuln-detail-item"><strong>Required Action:</strong> ${vuln.requiredAction}</div>` : ''}
          </div>
        `;
      } else if (vuln.type === 'CVE_MENTIONED') {
        detailsHtml = `
          <div class="vuln-details">
            <div class="vuln-detail-item"><strong>CVE:</strong> ${vuln.cveId}</div>
            <div class="vuln-detail-item"><strong>Product:</strong> ${vuln.product || 'N/A'}</div>
            <div class="vuln-detail-item"><strong>Vendor:</strong> ${vuln.vendor || 'N/A'}</div>
          </div>
        `;
      } else if (vuln.url) {
        detailsHtml = `
          <div class="vuln-details">
            <div class="vuln-detail-item"><strong>URL:</strong> <span class="url-text">${truncateUrl(vuln.url)}</span></div>
          </div>
        `;
      }

      return `
        <div class="vuln-item ${vuln.severity.toLowerCase()}">
          <div class="vuln-header">
            <span class="vuln-type">${formatType(vuln.type)}</span>
            <span class="vuln-severity ${vuln.severity.toLowerCase()}">${vuln.severity}</span>
          </div>
          <div class="vuln-description">${escapeHtml(vuln.description)}</div>
          ${detailsHtml}
        </div>
      `;
    }).join('');
  }
}

function formatType(type) {
  return type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
}

function truncateUrl(url, maxLength = 50) {
  if (url.length <= maxLength) return url;
  return url.substring(0, maxLength) + '...';
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
